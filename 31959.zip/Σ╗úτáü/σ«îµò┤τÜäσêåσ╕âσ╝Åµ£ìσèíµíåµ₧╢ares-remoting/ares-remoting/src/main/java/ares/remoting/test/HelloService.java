package ares.remoting.test;

/**
 * @author liyebing created on 16/10/5.
 * @version $Id$
 */
public interface HelloService {

    public String sayHello(String somebody);

}
