package service;

/**
 * @author liyebing created on 16/12/4.
 * @version $Id$
 */
public interface HelloService {

    public String sayHello(String content);


}
