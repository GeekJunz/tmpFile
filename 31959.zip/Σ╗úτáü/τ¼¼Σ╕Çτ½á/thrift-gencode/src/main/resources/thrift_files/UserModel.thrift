namespace java thrift.gencode.server

struct User{
   1:string name;
   2:string email;
}