package rpc.common;

/**
 * @author liyebing created on 17/2/12.
 * @version $Id$
 */

public interface UserService {

    public User findByName(String userName);

}
